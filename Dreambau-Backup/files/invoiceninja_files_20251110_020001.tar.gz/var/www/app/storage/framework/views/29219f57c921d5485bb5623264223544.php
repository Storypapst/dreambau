<?php echo e($title); ?>


<?php if(isset($body)): ?>
<?php echo e(strip_tags(str_replace("<br>", "\r\n", $body))); ?>

<?php endif; ?>

<?php if(isset($content)): ?>
<?php echo e(strip_tags(str_replace("<br>", "\r\n", $content))); ?>

<?php endif; ?>

<?php if(isset($whitelabel)): ?>
<?php if(!$whitelabel): ?>
<?php echo e(ctrans('texts.ninja_email_footer', ['site' => 'https://invoiceninja.com'])); ?>

<?php endif; ?>
<?php endif; ?><?php /**PATH /var/www/app/resources/views/email/admin/generic_text.blade.php ENDPATH**/ ?>