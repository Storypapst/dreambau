<link rel="stylesheet" href="/react/index-DHwofvx0.css">
<link rel="stylesheet" href="/react/inter.css">
<script type="module" crossorigin src="/react/index-DF750DJQ.js"></script>
<link rel="modulepreload" crossorigin href="/react/@babel-C6hKJqrj.js">
<link rel="modulepreload" crossorigin href="/react/react-CDYlDoz2.js">
<link rel="modulepreload" crossorigin href="/react/scheduler-C323NY8X.js">
<link rel="modulepreload" crossorigin href="/react/react-dom-BEENcUml.js">
<?php /**PATH /var/www/app/resources/views/react/head.blade.php ENDPATH**/ ?>