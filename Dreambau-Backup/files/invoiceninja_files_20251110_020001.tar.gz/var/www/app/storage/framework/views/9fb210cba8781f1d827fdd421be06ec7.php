<?php echo $title; ?>


<?php echo ctrans('texts.confirmation_message'); ?>


<?php echo $url; ?><?php /**PATH /var/www/app/resources/views/email/admin/verify_user_text.blade.php ENDPATH**/ ?>