<?php $__env->startComponent('email.template.admin', ['design' => 'light', 'settings' => $settings, 'logo' => $logo, 'url' => $url]); ?>
    <div class="center">
        <?php if(isset($greeting)): ?>
            <p><?php echo e($greeting); ?></p>
        <?php endif; ?>

        <?php if(isset($title)): ?>
            <h1><?php echo e($title); ?></h1>
        <?php endif; ?>

        <?php if(isset($h2)): ?>
            <h2><?php echo e($title); ?></h2>
        <?php endif; ?>

        <div style="margin-top: 10px; margin-bottom: 30px;">
            <?php if(isset($content)): ?>
                <?php echo nl2br($content, true); ?>

            <?php endif; ?>

            <?php if(isset($slot)): ?>
                <?php echo e($slot); ?>

            <?php endif; ?>
        </div>

        <?php if(isset($additional_info)): ?>
            <p><?php echo e($additional_info); ?></p>
        <?php endif; ?>

        <?php if($url): ?>

        <!--[if (gte mso 9)|(IE)]>
        <table align="center" cellspacing="0" cellpadding="0" style="width: 600px;">
            <tr>
            <td align="center" valign="top">
                <![endif]-->        
                <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" >
                <tbody><tr>
                <td align="center" class="new_button" style="border-radius: 2px; background-color: <?php echo e($settings->primary_color); ?> ;">
                    <a href="<?php echo e($url); ?>" target="_blank" class="new_button" style="text-decoration: none; border: 1px solid <?php echo e($settings->primary_color); ?>; display: inline-block; border-radius: 2px; padding-top: 15px; padding-bottom: 15px; padding-left: 25px; padding-right: 25px; font-size: 20px; color: #fff">
                    <singleline label="cta button"><?php echo e(ctrans($button)); ?></singleline>
                    </a>
                </td>
                </tr>
                </tbody>
                </table>
        <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
        </table>
        <![endif]-->


        <?php endif; ?>

        <?php if(isset($signature)): ?>
            <p><?php echo nl2br($signature); ?></p>
        <?php endif; ?>
    </div>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/app/resources/views/email/admin/generic.blade.php ENDPATH**/ ?>