<!DOCTYPE html>
<html data-report-errors="<?php echo e($report_errors); ?>" data-rc="<?php echo e($rc); ?>" data-user-agent="<?php echo e($user_agent); ?>" data-login="<?php echo e($login); ?>">
<head>
    <!-- Source: https://github.com/invoiceninja/invoiceninja -->
    <!-- Version: <?php echo e(config('ninja.app_version')); ?> -->
  <meta charset="UTF-8">
  <title><?php echo e(config('ninja.app_name')); ?></title>
  <meta name="google-signin-client_id" content="<?php echo e(config('services.google.client_id')); ?>">

  <?php echo $__env->make('react.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body class="h-full">
  <noscript>You need to enable JavaScript to run this app.</noscript>
  <div id="root"></div>
  
</body>

<!--

If you are reading this, there is a fair change that the react application has not loaded for you. There are a couple of solutions:

1. Download the release file from https://github.com/invoiceninja/invoiceninja and overwrite your current installation.
2. Switch back to the Flutter application by editing the database, you can do this with the following SQL

UPDATE accounts SET
set_react_as_default_ap = 0;

-->
</html>
<?php /**PATH /var/www/app/resources/views/react/index.blade.php ENDPATH**/ ?>