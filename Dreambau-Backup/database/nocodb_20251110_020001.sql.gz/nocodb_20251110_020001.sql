-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: nocodb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nc_api_tokens`
--

DROP TABLE IF EXISTS `nc_api_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_api_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `token` text COLLATE utf8mb4_unicode_ci,
  `expiry` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_sso_client_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_api_tokens_fk_user_id_index` (`fk_user_id`),
  KEY `nc_api_tokens_fk_sso_client_id_index` (`fk_sso_client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_api_tokens`
--

LOCK TABLES `nc_api_tokens` WRITE;
/*!40000 ALTER TABLE `nc_api_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_api_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_audit_v2`
--

DROP TABLE IF EXISTS `nc_audit_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_audit_v2` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `op_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `op_sub_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_ref_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_parent_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_org_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `version` smallint DEFAULT '0',
  `old_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_audit_v2_fk_workspace_idx` (`fk_workspace_id`),
  KEY `nc_audit_v2_tenant_idx` (`base_id`,`fk_workspace_id`),
  KEY `nc_record_audit_v2_tenant_idx` (`base_id`,`fk_model_id`,`row_id`,`fk_workspace_id`),
  KEY `nc_audit_v2_old_id_index` (`old_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_audit_v2`
--

LOCK TABLES `nc_audit_v2` WRITE;
/*!40000 ALTER TABLE `nc_audit_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_audit_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_audit_v2_old`
--

DROP TABLE IF EXISTS `nc_audit_v2_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_audit_v2_old` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `op_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `op_sub_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `version` smallint unsigned DEFAULT '0',
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_ref_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_parent_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `nc_audit_v2_base_id_foreign` (`source_id`),
  KEY `nc_audit_v2_row_id_index` (`row_id`),
  KEY `nc_audit_v2_fk_model_id_index` (`fk_model_id`),
  KEY `nc_audit_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_audit_v2_old`
--

LOCK TABLES `nc_audit_v2_old` WRITE;
/*!40000 ALTER TABLE `nc_audit_v2_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_audit_v2_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_base_users_v2`
--

DROP TABLE IF EXISTS `nc_base_users_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_base_users_v2` (
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` text COLLATE utf8mb4_unicode_ci,
  `starred` tinyint(1) DEFAULT NULL,
  `pinned` tinyint(1) DEFAULT NULL,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `hidden` float(8,2) DEFAULT NULL,
  `opened_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `invited_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`base_id`,`fk_user_id`),
  KEY `nc_project_users_v2_fk_user_id_index` (`fk_user_id`),
  KEY `nc_base_users_v2_base_id_index` (`base_id`),
  KEY `nc_base_users_v2_invited_by_index` (`invited_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_base_users_v2`
--

LOCK TABLES `nc_base_users_v2` WRITE;
/*!40000 ALTER TABLE `nc_base_users_v2` DISABLE KEYS */;
INSERT INTO `nc_base_users_v2` VALUES ('pixp4cik3n9fbbq','usc8u5scvvx5ftm7','creator',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-09 03:03:42','2025-11-09 03:03:42','usfwuzdmgrr348dy'),('pixp4cik3n9fbbq','usfwuzdmgrr348dy','owner',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-08 23:34:23','2025-11-08 23:34:23',NULL);
/*!40000 ALTER TABLE `nc_base_users_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_bases_v2`
--

DROP TABLE IF EXISTS `nc_bases_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_bases_v2` (
  `id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `is_meta` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `default_role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_bases_v2`
--

LOCK TABLES `nc_bases_v2` WRITE;
/*!40000 ALTER TABLE `nc_bases_v2` DISABLE KEYS */;
INSERT INTO `nc_bases_v2` VALUES ('pixp4cik3n9fbbq','Base','nc_z1wr__',NULL,NULL,'{\"iconColor\":\"#6A7184\"}',NULL,NULL,NULL,NULL,0,1,1.00,'2025-11-08 23:34:23','2025-11-08 23:34:23',NULL);
/*!40000 ALTER TABLE `nc_bases_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_calendar_view_columns_v2`
--

DROP TABLE IF EXISTS `nc_calendar_view_columns_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_calendar_view_columns_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show` tinyint(1) DEFAULT NULL,
  `bold` tinyint(1) DEFAULT NULL,
  `underline` tinyint(1) DEFAULT NULL,
  `italic` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_calendar_view_columns_v2_fk_view_id_fk_column_id_index` (`fk_view_id`,`fk_column_id`),
  KEY `nc_calendar_view_columns_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_calendar_view_columns_v2`
--

LOCK TABLES `nc_calendar_view_columns_v2` WRITE;
/*!40000 ALTER TABLE `nc_calendar_view_columns_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_calendar_view_columns_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_calendar_view_range_v2`
--

DROP TABLE IF EXISTS `nc_calendar_view_range_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_calendar_view_range_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_to_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_from_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_calendar_view_range_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_calendar_view_range_v2`
--

LOCK TABLES `nc_calendar_view_range_v2` WRITE;
/*!40000 ALTER TABLE `nc_calendar_view_range_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_calendar_view_range_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_calendar_view_v2`
--

DROP TABLE IF EXISTS `nc_calendar_view_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_calendar_view_v2` (
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_cover_image_col_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`fk_view_id`),
  KEY `nc_calendar_view_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_calendar_view_v2`
--

LOCK TABLES `nc_calendar_view_v2` WRITE;
/*!40000 ALTER TABLE `nc_calendar_view_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_calendar_view_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_barcode_v2`
--

DROP TABLE IF EXISTS `nc_col_barcode_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_barcode_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_barcode_value_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode_format` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_barcode_v2_fk_barcode_value_column_id_foreign` (`fk_barcode_value_column_id`),
  KEY `nc_col_barcode_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_barcode_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_barcode_v2`
--

LOCK TABLES `nc_col_barcode_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_barcode_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_barcode_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_button_v2`
--

DROP TABLE IF EXISTS `nc_col_button_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_button_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` text COLLATE utf8mb4_unicode_ci,
  `theme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formula` text COLLATE utf8mb4_unicode_ci,
  `formula_raw` text COLLATE utf8mb4_unicode_ci,
  `error` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parsed_tree` text COLLATE utf8mb4_unicode_ci,
  `fk_webhook_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fk_integration_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `output_column_ids` text COLLATE utf8mb4_unicode_ci,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_button_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_button_context` (`base_id`,`fk_workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_button_v2`
--

LOCK TABLES `nc_col_button_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_button_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_button_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_formula_v2`
--

DROP TABLE IF EXISTS `nc_col_formula_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_formula_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formula` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `formula_raw` text COLLATE utf8mb4_unicode_ci,
  `error` text COLLATE utf8mb4_unicode_ci,
  `deleted` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `parsed_tree` text COLLATE utf8mb4_unicode_ci,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_formula_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_formula_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_formula_v2`
--

LOCK TABLES `nc_col_formula_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_formula_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_formula_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_long_text_v2`
--

DROP TABLE IF EXISTS `nc_col_long_text_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_long_text_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_integration_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prompt` text COLLATE utf8mb4_unicode_ci,
  `prompt_raw` text COLLATE utf8mb4_unicode_ci,
  `error` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_col_long_text_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_long_text_context` (`base_id`,`fk_workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_long_text_v2`
--

LOCK TABLES `nc_col_long_text_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_long_text_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_long_text_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_lookup_v2`
--

DROP TABLE IF EXISTS `nc_col_lookup_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_lookup_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_relation_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_lookup_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_lookup_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_lookup_v2_fk_relation_column_id_index` (`fk_relation_column_id`),
  KEY `nc_col_lookup_v2_fk_lookup_column_id_index` (`fk_lookup_column_id`),
  KEY `nc_col_lookup_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_lookup_v2`
--

LOCK TABLES `nc_col_lookup_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_lookup_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_lookup_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_qrcode_v2`
--

DROP TABLE IF EXISTS `nc_col_qrcode_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_qrcode_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_qr_value_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_qrcode_v2_fk_qr_value_column_id_foreign` (`fk_qr_value_column_id`),
  KEY `nc_col_qrcode_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_qrcode_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_qrcode_v2`
--

LOCK TABLES `nc_col_qrcode_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_qrcode_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_qrcode_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_relations_v2`
--

DROP TABLE IF EXISTS `nc_col_relations_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_relations_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_db_alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `virtual` tinyint(1) DEFAULT NULL,
  `db_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_related_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_child_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_parent_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_mm_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_mm_child_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_mm_parent_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ur` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_index_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fk_target_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_related_base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_mm_base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_related_source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_mm_source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_relations_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_relations_v2_fk_related_model_id_index` (`fk_related_model_id`),
  KEY `nc_col_relations_v2_fk_child_column_id_index` (`fk_child_column_id`),
  KEY `nc_col_relations_v2_fk_parent_column_id_index` (`fk_parent_column_id`),
  KEY `nc_col_relations_v2_fk_mm_model_id_index` (`fk_mm_model_id`),
  KEY `nc_col_relations_v2_fk_mm_child_column_id_index` (`fk_mm_child_column_id`),
  KEY `nc_col_relations_v2_fk_mm_parent_column_id_index` (`fk_mm_parent_column_id`),
  KEY `nc_col_relations_v2_fk_target_view_id_index` (`fk_target_view_id`),
  KEY `nc_col_relations_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_relations_v2`
--

LOCK TABLES `nc_col_relations_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_relations_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_relations_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_rollup_v2`
--

DROP TABLE IF EXISTS `nc_col_rollup_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_rollup_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_relation_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_rollup_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rollup_function` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_rollup_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_rollup_v2_fk_relation_column_id_index` (`fk_relation_column_id`),
  KEY `nc_col_rollup_v2_fk_rollup_column_id_index` (`fk_rollup_column_id`),
  KEY `nc_col_rollup_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_rollup_v2`
--

LOCK TABLES `nc_col_rollup_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_rollup_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_rollup_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_col_select_options_v2`
--

DROP TABLE IF EXISTS `nc_col_select_options_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_col_select_options_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_col_select_options_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_col_select_options_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_col_select_options_v2`
--

LOCK TABLES `nc_col_select_options_v2` WRITE;
/*!40000 ALTER TABLE `nc_col_select_options_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_col_select_options_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_columns_v2`
--

DROP TABLE IF EXISTS `nc_columns_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_columns_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `column_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uidt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `np` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ns` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cop` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pk` tinyint(1) DEFAULT NULL,
  `pv` tinyint(1) DEFAULT NULL,
  `rqd` tinyint(1) DEFAULT NULL,
  `un` tinyint(1) DEFAULT NULL,
  `ct` text COLLATE utf8mb4_unicode_ci,
  `ai` tinyint(1) DEFAULT NULL,
  `unique` tinyint(1) DEFAULT NULL,
  `cdf` text COLLATE utf8mb4_unicode_ci,
  `cc` text COLLATE utf8mb4_unicode_ci,
  `csn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dtx` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dtxp` text COLLATE utf8mb4_unicode_ci,
  `dtxs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `au` tinyint(1) DEFAULT NULL,
  `validate` text COLLATE utf8mb4_unicode_ci,
  `virtual` tinyint(1) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `system` tinyint(1) DEFAULT '0',
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `readonly` tinyint(1) DEFAULT '0',
  `custom_index_name` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_columns_v2_fk_model_id_index` (`fk_model_id`),
  KEY `nc_columns_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_columns_v2`
--

LOCK TABLES `nc_columns_v2` WRITE;
/*!40000 ALTER TABLE `nc_columns_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_columns_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_comment_reactions`
--

DROP TABLE IF EXISTS `nc_comment_reactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_comment_reactions` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reaction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_comment_reactions_row_id_index` (`row_id`),
  KEY `nc_comment_reactions_comment_id_index` (`comment_id`),
  KEY `nc_comment_reactions_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_comment_reactions`
--

LOCK TABLES `nc_comment_reactions` WRITE;
/*!40000 ALTER TABLE `nc_comment_reactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_comment_reactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_comments`
--

DROP TABLE IF EXISTS `nc_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_comments` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolved_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolved_by_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_comment_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_comments_row_id_fk_model_id_index` (`row_id`,`fk_model_id`),
  KEY `nc_comments_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_comments`
--

LOCK TABLES `nc_comments` WRITE;
/*!40000 ALTER TABLE `nc_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_dashboards_v2`
--

DROP TABLE IF EXISTS `nc_dashboards_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_dashboards_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `order` int unsigned DEFAULT NULL,
  `created_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owned_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_custom_url_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_dashboards_context` (`base_id`,`fk_workspace_id`),
  KEY `share_uuid_idx` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_dashboards_v2`
--

LOCK TABLES `nc_dashboards_v2` WRITE;
/*!40000 ALTER TABLE `nc_dashboards_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_dashboards_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_data_reflection`
--

DROP TABLE IF EXISTS `nc_data_reflection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_data_reflection` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `database` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_data_reflection_fk_workspace_id_index` (`fk_workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_data_reflection`
--

LOCK TABLES `nc_data_reflection` WRITE;
/*!40000 ALTER TABLE `nc_data_reflection` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_data_reflection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_disabled_models_for_role_v2`
--

DROP TABLE IF EXISTS `nc_disabled_models_for_role_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_disabled_models_for_role_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_disabled_models_for_role_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_disabled_models_for_role_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_disabled_models_for_role_v2`
--

LOCK TABLES `nc_disabled_models_for_role_v2` WRITE;
/*!40000 ALTER TABLE `nc_disabled_models_for_role_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_disabled_models_for_role_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_extensions`
--

DROP TABLE IF EXISTS `nc_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_extensions` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kv_store` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_extensions_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_extensions`
--

LOCK TABLES `nc_extensions` WRITE;
/*!40000 ALTER TABLE `nc_extensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_file_references`
--

DROP TABLE IF EXISTS `nc_file_references`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_file_references` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_url` text COLLATE utf8mb4_unicode_ci,
  `file_size` int DEFAULT NULL,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_external` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_fr_context` (`base_id`,`fk_workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_file_references`
--

LOCK TABLES `nc_file_references` WRITE;
/*!40000 ALTER TABLE `nc_file_references` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_file_references` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_filter_exp_v2`
--

DROP TABLE IF EXISTS `nc_filter_exp_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_filter_exp_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_hook_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_parent_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logical_op` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparison_op` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `is_group` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comparison_sub_op` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_link_col_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_value_col_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_parent_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_row_color_condition_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_widget_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_filter_exp_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_filter_exp_v2_fk_hook_id_index` (`fk_hook_id`),
  KEY `nc_filter_exp_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_filter_exp_v2_fk_parent_id_index` (`fk_parent_id`),
  KEY `nc_filter_exp_v2_fk_link_col_id_index` (`fk_link_col_id`),
  KEY `nc_filter_exp_v2_fk_value_col_id_index` (`fk_value_col_id`),
  KEY `nc_filter_exp_v2_base_id_index` (`base_id`),
  KEY `nc_filter_exp_v2_fk_parent_column_id_index` (`fk_parent_column_id`),
  KEY `nc_filter_exp_v2_fk_widget_id_index` (`fk_widget_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_filter_exp_v2`
--

LOCK TABLES `nc_filter_exp_v2` WRITE;
/*!40000 ALTER TABLE `nc_filter_exp_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_filter_exp_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_form_view_columns_v2`
--

DROP TABLE IF EXISTS `nc_form_view_columns_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_form_view_columns_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` text COLLATE utf8mb4_unicode_ci,
  `help` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `required` tinyint(1) DEFAULT NULL,
  `show` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `enable_scanner` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_form_view_columns_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_form_view_columns_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_form_view_columns_v2_fk_view_id_fk_column_id_index` (`fk_view_id`,`fk_column_id`),
  KEY `nc_form_view_columns_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_form_view_columns_v2`
--

LOCK TABLES `nc_form_view_columns_v2` WRITE;
/*!40000 ALTER TABLE `nc_form_view_columns_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_form_view_columns_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_form_view_v2`
--

DROP TABLE IF EXISTS `nc_form_view_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_form_view_v2` (
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subheading` text COLLATE utf8mb4_unicode_ci,
  `success_msg` text COLLATE utf8mb4_unicode_ci,
  `redirect_url` text COLLATE utf8mb4_unicode_ci,
  `redirect_after_secs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submit_another_form` tinyint(1) DEFAULT NULL,
  `show_blank_form` tinyint(1) DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_image_url` text COLLATE utf8mb4_unicode_ci,
  `logo_url` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`fk_view_id`),
  KEY `nc_form_view_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_form_view_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_form_view_v2`
--

LOCK TABLES `nc_form_view_v2` WRITE;
/*!40000 ALTER TABLE `nc_form_view_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_form_view_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_gallery_view_columns_v2`
--

DROP TABLE IF EXISTS `nc_gallery_view_columns_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_gallery_view_columns_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `help` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_gallery_view_columns_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_gallery_view_columns_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_gallery_view_columns_v2_fk_view_id_fk_column_id_index` (`fk_view_id`,`fk_column_id`),
  KEY `nc_gallery_view_columns_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_gallery_view_columns_v2`
--

LOCK TABLES `nc_gallery_view_columns_v2` WRITE;
/*!40000 ALTER TABLE `nc_gallery_view_columns_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_gallery_view_columns_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_gallery_view_v2`
--

DROP TABLE IF EXISTS `nc_gallery_view_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_gallery_view_v2` (
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_enabled` tinyint(1) DEFAULT NULL,
  `prev_enabled` tinyint(1) DEFAULT NULL,
  `cover_image_idx` int DEFAULT NULL,
  `fk_cover_image_col_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restrict_types` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restrict_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restrict_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public` tinyint(1) DEFAULT NULL,
  `dimensions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsive_columns` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`fk_view_id`),
  KEY `nc_gallery_view_v2_fk_cover_image_col_id_foreign` (`fk_cover_image_col_id`),
  KEY `nc_gallery_view_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_gallery_view_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_gallery_view_v2`
--

LOCK TABLES `nc_gallery_view_v2` WRITE;
/*!40000 ALTER TABLE `nc_gallery_view_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_gallery_view_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_grid_view_columns_v2`
--

DROP TABLE IF EXISTS `nc_grid_view_columns_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_grid_view_columns_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `help` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '200px',
  `show` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `group_by` tinyint(1) DEFAULT NULL,
  `group_by_order` float(8,2) DEFAULT NULL,
  `group_by_sort` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aggregation` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_grid_view_columns_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_grid_view_columns_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_grid_view_columns_v2_fk_view_id_fk_column_id_index` (`fk_view_id`,`fk_column_id`),
  KEY `nc_grid_view_columns_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_grid_view_columns_v2`
--

LOCK TABLES `nc_grid_view_columns_v2` WRITE;
/*!40000 ALTER TABLE `nc_grid_view_columns_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_grid_view_columns_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_grid_view_v2`
--

DROP TABLE IF EXISTS `nc_grid_view_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_grid_view_v2` (
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `row_height` int DEFAULT NULL,
  PRIMARY KEY (`fk_view_id`),
  KEY `nc_grid_view_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_grid_view_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_grid_view_v2`
--

LOCK TABLES `nc_grid_view_v2` WRITE;
/*!40000 ALTER TABLE `nc_grid_view_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_grid_view_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_hook_logs_v2`
--

DROP TABLE IF EXISTS `nc_hook_logs_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_hook_logs_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_hook_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_call` tinyint(1) DEFAULT '1',
  `payload` text COLLATE utf8mb4_unicode_ci,
  `conditions` text COLLATE utf8mb4_unicode_ci,
  `notification` text COLLATE utf8mb4_unicode_ci,
  `error_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_ci,
  `execution_time` int DEFAULT NULL,
  `response` text COLLATE utf8mb4_unicode_ci,
  `triggered_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_hook_logs_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_hook_logs_v2`
--

LOCK TABLES `nc_hook_logs_v2` WRITE;
/*!40000 ALTER TABLE `nc_hook_logs_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_hook_logs_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_hook_trigger_fields`
--

DROP TABLE IF EXISTS `nc_hook_trigger_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_hook_trigger_fields` (
  `fk_hook_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fk_workspace_id`,`base_id`,`fk_hook_id`,`fk_column_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_hook_trigger_fields`
--

LOCK TABLES `nc_hook_trigger_fields` WRITE;
/*!40000 ALTER TABLE `nc_hook_trigger_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_hook_trigger_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_hooks_v2`
--

DROP TABLE IF EXISTS `nc_hooks_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_hooks_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `env` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'all',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `async` tinyint(1) DEFAULT '0',
  `payload` tinyint(1) DEFAULT '1',
  `url` text COLLATE utf8mb4_unicode_ci,
  `headers` text COLLATE utf8mb4_unicode_ci,
  `condition` tinyint(1) DEFAULT '0',
  `notification` text COLLATE utf8mb4_unicode_ci,
  `retries` int DEFAULT '0',
  `retry_interval` int DEFAULT '60000',
  `timeout` int DEFAULT '60000',
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trigger_field` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `nc_hooks_v2_fk_model_id_index` (`fk_model_id`),
  KEY `nc_hooks_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_hooks_v2`
--

LOCK TABLES `nc_hooks_v2` WRITE;
/*!40000 ALTER TABLE `nc_hooks_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_hooks_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_integrations_store_v2`
--

DROP TABLE IF EXISTS `nc_integrations_store_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_integrations_store_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_integration_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `slot_0` text COLLATE utf8mb4_unicode_ci,
  `slot_1` text COLLATE utf8mb4_unicode_ci,
  `slot_2` text COLLATE utf8mb4_unicode_ci,
  `slot_3` text COLLATE utf8mb4_unicode_ci,
  `slot_4` text COLLATE utf8mb4_unicode_ci,
  `slot_5` int DEFAULT NULL,
  `slot_6` int DEFAULT NULL,
  `slot_7` int DEFAULT NULL,
  `slot_8` int DEFAULT NULL,
  `slot_9` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_integrations_store_v2_fk_integration_id_index` (`fk_integration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_integrations_store_v2`
--

LOCK TABLES `nc_integrations_store_v2` WRITE;
/*!40000 ALTER TABLE `nc_integrations_store_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_integrations_store_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_integrations_v2`
--

DROP TABLE IF EXISTS `nc_integrations_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_integrations_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_private` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  `created_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_default` tinyint(1) DEFAULT '0',
  `is_encrypted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `nc_integrations_v2_type_index` (`type`),
  KEY `nc_integrations_v2_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_integrations_v2`
--

LOCK TABLES `nc_integrations_v2` WRITE;
/*!40000 ALTER TABLE `nc_integrations_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_integrations_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_jobs`
--

DROP TABLE IF EXISTS `nc_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_jobs` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` text COLLATE utf8mb4_unicode_ci,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_jobs_context` (`base_id`,`fk_workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_jobs`
--

LOCK TABLES `nc_jobs` WRITE;
/*!40000 ALTER TABLE `nc_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_kanban_view_columns_v2`
--

DROP TABLE IF EXISTS `nc_kanban_view_columns_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_kanban_view_columns_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `help` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_kanban_view_columns_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_kanban_view_columns_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_kanban_view_columns_v2_fk_view_id_fk_column_id_index` (`fk_view_id`,`fk_column_id`),
  KEY `nc_kanban_view_columns_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_kanban_view_columns_v2`
--

LOCK TABLES `nc_kanban_view_columns_v2` WRITE;
/*!40000 ALTER TABLE `nc_kanban_view_columns_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_kanban_view_columns_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_kanban_view_v2`
--

DROP TABLE IF EXISTS `nc_kanban_view_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_kanban_view_v2` (
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public` tinyint(1) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_all_fields` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fk_grp_col_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_cover_image_col_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`fk_view_id`),
  KEY `nc_kanban_view_v2_fk_cover_image_col_id_foreign` (`fk_cover_image_col_id`),
  KEY `nc_kanban_view_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_kanban_view_v2_fk_grp_col_id_index` (`fk_grp_col_id`),
  KEY `nc_kanban_view_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_kanban_view_v2`
--

LOCK TABLES `nc_kanban_view_v2` WRITE;
/*!40000 ALTER TABLE `nc_kanban_view_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_kanban_view_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_map_view_columns_v2`
--

DROP TABLE IF EXISTS `nc_map_view_columns_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_map_view_columns_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `help` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_map_view_columns_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_map_view_columns_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_map_view_columns_v2_fk_view_id_fk_column_id_index` (`fk_view_id`,`fk_column_id`),
  KEY `nc_map_view_columns_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_map_view_columns_v2`
--

LOCK TABLES `nc_map_view_columns_v2` WRITE;
/*!40000 ALTER TABLE `nc_map_view_columns_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_map_view_columns_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_map_view_v2`
--

DROP TABLE IF EXISTS `nc_map_view_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_map_view_v2` (
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_geo_data_col_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`fk_view_id`),
  KEY `nc_map_view_v2_base_id_foreign` (`source_id`),
  KEY `nc_map_view_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_map_view_v2_fk_geo_data_col_id_index` (`fk_geo_data_col_id`),
  KEY `nc_map_view_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_map_view_v2`
--

LOCK TABLES `nc_map_view_v2` WRITE;
/*!40000 ALTER TABLE `nc_map_view_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_map_view_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_mcp_tokens`
--

DROP TABLE IF EXISTS `nc_mcp_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_mcp_tokens` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_mc_tokens_context` (`base_id`,`fk_workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_mcp_tokens`
--

LOCK TABLES `nc_mcp_tokens` WRITE;
/*!40000 ALTER TABLE `nc_mcp_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_mcp_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_models_v2`
--

DROP TABLE IF EXISTS `nc_models_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_models_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'table',
  `meta` mediumtext COLLATE utf8mb4_unicode_ci,
  `schema` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) DEFAULT '1',
  `mm` tinyint(1) DEFAULT '0',
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pinned` tinyint(1) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text COLLATE utf8mb4_unicode_ci,
  `synced` tinyint(1) DEFAULT '0',
  `created_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owned_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_custom_url_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_models_v2_source_id_index` (`source_id`),
  KEY `nc_models_v2_base_id_index` (`base_id`),
  KEY `nc_models_v2_uuid_index` (`uuid`),
  KEY `nc_models_v2_type_index` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_models_v2`
--

LOCK TABLES `nc_models_v2` WRITE;
/*!40000 ALTER TABLE `nc_models_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_models_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_orgs_v2`
--

DROP TABLE IF EXISTS `nc_orgs_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_orgs_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_orgs_v2`
--

LOCK TABLES `nc_orgs_v2` WRITE;
/*!40000 ALTER TABLE `nc_orgs_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_orgs_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_permission_subjects`
--

DROP TABLE IF EXISTS `nc_permission_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_permission_subjects` (
  `fk_permission_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fk_permission_id`,`subject_type`,`subject_id`),
  KEY `nc_permission_subjects_context` (`fk_workspace_id`,`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_permission_subjects`
--

LOCK TABLES `nc_permission_subjects` WRITE;
/*!40000 ALTER TABLE `nc_permission_subjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_permission_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_permissions`
--

DROP TABLE IF EXISTS `nc_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_permissions` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enforce_for_form` tinyint(1) DEFAULT '1',
  `enforce_for_automation` tinyint(1) DEFAULT '1',
  `granted_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `granted_role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_permissions_context` (`base_id`,`fk_workspace_id`),
  KEY `nc_permissions_entity` (`entity`,`entity_id`,`permission`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_permissions`
--

LOCK TABLES `nc_permissions` WRITE;
/*!40000 ALTER TABLE `nc_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_plugins_v2`
--

DROP TABLE IF EXISTS `nc_plugins_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_plugins_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active` tinyint(1) DEFAULT '0',
  `rating` float(8,2) DEFAULT NULL,
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'install',
  `status_details` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `input_schema` text COLLATE utf8mb4_unicode_ci,
  `input` text COLLATE utf8mb4_unicode_ci,
  `creator` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creator_website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_plugins_v2`
--

LOCK TABLES `nc_plugins_v2` WRITE;
/*!40000 ALTER TABLE `nc_plugins_v2` DISABLE KEYS */;
INSERT INTO `nc_plugins_v2` VALUES ('aws-s3','S3','Amazon Simple Storage Service (Amazon S3) is an object storage service that offers industry-leading scalability, data availability, security, and performance.',0,NULL,'0.0.6',NULL,'install',NULL,'plugins/s3.png',NULL,'Storage','Storage','{\"title\":\"Configure Amazon S3\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"region\",\"label\":\"Region\",\"placeholder\":\"Region\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"endpoint\",\"label\":\"Endpoint\",\"placeholder\":\"Endpoint\",\"type\":\"SingleLineText\",\"required\":false},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":false},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":false},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"\",\"type\":\"SingleLineText\",\"required\":false},{\"key\":\"force_path_style\",\"label\":\"Force Path Style\",\"placeholder\":\"Default set to false\",\"type\":\"Checkbox\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in AWS S3.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('backblaze','Backblaze','Backblaze B2 is enterprise-grade, S3 compatible storage that companies around the world use to store and serve data while improving their cloud OpEx vs. Amazon S3 and others.',0,NULL,'0.0.5',NULL,'install',NULL,'plugins/backblaze.jpeg',NULL,'Storage','Storage','{\"title\":\"Configure Backblaze B2\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"region\",\"label\":\"Region\",\"placeholder\":\"e.g. us-west-001\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"i.e. keyID in App Keys\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"i.e. applicationKey in App Keys\",\"type\":\"Password\",\"required\":true},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"Default set to public-read\",\"type\":\"SingleLineText\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in Backblaze B2.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('cloudflare-r2','Cloudflare R2','Cloudflare R2 is an S3-compatible, zero egress-fee, globally distributed object storage.',0,NULL,'0.0.3',NULL,'install',NULL,'plugins/r2.png',NULL,'Storage','Storage','{\"title\":\"Configure Cloudflare R2 Storage\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"hostname\",\"label\":\"Host Name\",\"placeholder\":\"e.g.: *****.r2.cloudflarestorage.com\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in Cloudflare R2 Storage.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('discord','Discord','Discord is the easiest way to talk over voice, video, and text. Talk, chat, hang out, and stay close with your friends and communities.',0,NULL,'0.0.1',NULL,'install',NULL,'plugins/discord.png',NULL,'Chat','Chat','{\"title\":\"Configure Discord\",\"array\":true,\"items\":[{\"key\":\"channel\",\"label\":\"Channel Name\",\"placeholder\":\"Channel Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"webhook_url\",\"label\":\"Webhook URL\",\"type\":\"Password\",\"placeholder\":\"Webhook URL\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully installed and Discord is enabled for notification.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('gcs','GCS','Google Cloud Storage is a RESTful online file storage web service for storing and accessing data on Google Cloud Platform infrastructure.',0,NULL,'0.0.4',NULL,'install',NULL,'plugins/gcs.png',NULL,'Storage','Storage','{\"title\":\"Configure Google Cloud Storage\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"client_email\",\"label\":\"Client Email\",\"placeholder\":\"Client Email\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"private_key\",\"label\":\"Private Key\",\"placeholder\":\"Private Key\",\"type\":\"Password\",\"required\":true},{\"key\":\"project_id\",\"label\":\"Project ID\",\"placeholder\":\"Project ID\",\"type\":\"SingleLineText\",\"required\":false},{\"key\":\"uniform_bucket_level_access\",\"label\":\"Uniform Bucket Level Access\",\"type\":\"Checkbox\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in Google Cloud Storage.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('linode','Linode','S3-compatible Linode Object Storage makes it easy and more affordable to manage unstructured data such as content assets, as well as sophisticated and data-intensive storage challenges around artificial intelligence and machine learning.',0,NULL,'0.0.4',NULL,'install',NULL,'plugins/linode.svg',NULL,'Storage','Storage','{\"title\":\"Configure Linode Object Storage\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"region\",\"label\":\"Region\",\"placeholder\":\"Region\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"Default set to public-read\",\"type\":\"SingleLineText\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in Linode Object Storage.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('mailersend','MailerSend','MailerSend email client',0,NULL,'0.0.2',NULL,'install',NULL,'plugins/mailersend.svg',NULL,'Email','Email','{\"title\":\"Configure MailerSend\",\"items\":[{\"key\":\"api_key\",\"label\":\"API key\",\"placeholder\":\"eg: ***************\",\"type\":\"Password\",\"required\":true},{\"key\":\"from\",\"label\":\"From\",\"placeholder\":\"eg: admin@run.com\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"from_name\",\"label\":\"From name\",\"placeholder\":\"eg: Adam\",\"type\":\"SingleLineText\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Email notifications are now set up using MailerSend.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('mattermost','Mattermost','Mattermost brings all your team communication into one place, making it searchable and accessible anywhere.',0,NULL,'0.0.1',NULL,'install',NULL,'plugins/mattermost.png',NULL,'Chat','Chat','{\"title\":\"Configure Mattermost\",\"array\":true,\"items\":[{\"key\":\"channel\",\"label\":\"Channel Name\",\"placeholder\":\"Channel Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"webhook_url\",\"label\":\"Webhook URL\",\"placeholder\":\"Webhook URL\",\"type\":\"Password\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully installed and Mattermost is enabled for notification.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('minio','Minio','MinIO is a High Performance Object Storage released under Apache License v2.0. It is API compatible with Amazon S3 cloud storage service.',0,NULL,'0.0.5',NULL,'install',NULL,'plugins/minio.png',NULL,'Storage','Storage','{\"title\":\"Configure Minio\",\"items\":[{\"key\":\"endPoint\",\"label\":\"Minio Endpoint\",\"placeholder\":\"Minio Endpoint\",\"type\":\"SingleLineText\",\"required\":true,\"help_text\":\"Hostnames can’t include underscores (_) due to DNS standard limitations. Update the hostname if you see an Invalid endpoint error.\"},{\"key\":\"port\",\"label\":\"Port\",\"placeholder\":\"Port\",\"type\":\"Number\",\"required\":true},{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true},{\"key\":\"ca\",\"label\":\"Ca\",\"placeholder\":\"Ca\",\"type\":\"LongText\"},{\"key\":\"useSSL\",\"label\":\"Use SSL\",\"placeholder\":\"Use SSL\",\"type\":\"Checkbox\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in Minio.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('ms-teams','Microsoft Teams','Microsoft Teams is for everyone · Instantly go from group chat to video call with the touch of a button.',0,NULL,'0.0.1',NULL,'install',NULL,'plugins/teams.ico',NULL,'Chat','Chat','{\"title\":\"Configure Microsoft Teams\",\"array\":true,\"items\":[{\"key\":\"channel\",\"label\":\"Channel Name\",\"placeholder\":\"Channel Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"webhook_url\",\"label\":\"Webhook URL\",\"placeholder\":\"Webhook URL\",\"type\":\"Password\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully installed and Microsoft Teams is enabled for notification.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('ovh','Ovh','Upload your files to a space that you can access via HTTPS using the OpenStack Swift API, or the S3 API. ',0,NULL,'0.0.4',NULL,'install',NULL,'plugins/ovhCloud.png',NULL,'Storage','Storage','{\"title\":\"Configure OvhCloud Object Storage\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"region\",\"label\":\"Region\",\"placeholder\":\"Region\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"Default set to public-read\",\"type\":\"SingleLineText\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in OvhCloud Object Storage.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('scaleway','Scaleway','Scaleway Object Storage is an S3-compatible object store from Scaleway Cloud Platform.',0,NULL,'0.0.4',NULL,'install',NULL,'plugins/scaleway.png',NULL,'Storage','Storage','{\"title\":\"Setup Scaleway\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket name\",\"placeholder\":\"Bucket name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"region\",\"label\":\"Region of bucket\",\"placeholder\":\"Region of bucket\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"Default set to public-read\",\"type\":\"SingleLineText\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in Scaleway Object Storage.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('ses','SES','Amazon Simple Email Service (SES) is a cost-effective, flexible, and scalable email service that enables developers to send mail from within any application.',0,NULL,'0.0.2',NULL,'install',NULL,'plugins/aws.png',NULL,'Email','Email','{\"title\":\"Configure Amazon Simple Email Service (SES)\",\"items\":[{\"key\":\"from\",\"label\":\"From\",\"placeholder\":\"From\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"region\",\"label\":\"Region\",\"placeholder\":\"Region\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Email notifications are now set up using Amazon SES.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('slack','Slack','Slack brings team communication and collaboration into one place so you can get more work done, whether you belong to a large enterprise or a small business. ',0,NULL,'0.0.1',NULL,'install',NULL,'plugins/slack.webp',NULL,'Chat','Chat','{\"title\":\"Configure Slack\",\"array\":true,\"items\":[{\"key\":\"channel\",\"label\":\"Channel Name\",\"placeholder\":\"Channel Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"webhook_url\",\"label\":\"Webhook URL\",\"placeholder\":\"Webhook URL\",\"type\":\"Password\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully installed and Slack is enabled for notification.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('smtp','SMTP','SMTP email client',0,NULL,'0.0.5',NULL,'install',NULL,NULL,NULL,'Email','Email','{\"title\":\"Configure Email SMTP\",\"items\":[{\"key\":\"from\",\"label\":\"From address\",\"placeholder\":\"admin@example.com\",\"type\":\"SingleLineText\",\"required\":true,\"help_text\":\"Enter the e-mail address to be used as the sender (appearing in the \'From\' field of sent e-mails).\"},{\"key\":\"host\",\"label\":\"SMTP server\",\"placeholder\":\"smtp.example.com\",\"help_text\":\"Enter the SMTP hostname. If you do not have this information available, contact your email service provider.\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"name\",\"label\":\"From domain\",\"placeholder\":\"your-domain.com\",\"type\":\"SingleLineText\",\"required\":true,\"help_text\":\"Specify the domain name that will be used in the \'From\' address (e.g., yourdomain.com). This should match the domain of the \'From\' address.\"},{\"key\":\"port\",\"label\":\"SMTP port\",\"placeholder\":\"Port\",\"type\":\"SingleLineText\",\"required\":true,\"help_text\":\"Enter the port number used by the SMTP server (e.g., 587 for TLS, 465 for SSL, or 25 for insecure connections).\"},{\"key\":\"username\",\"label\":\"Username\",\"placeholder\":\"Username\",\"type\":\"SingleLineText\",\"required\":false,\"help_text\":\"Enter the username to authenticate with the SMTP server. This is usually your email address.\"},{\"key\":\"password\",\"label\":\"Password\",\"placeholder\":\"Password\",\"type\":\"Password\",\"required\":false,\"help_text\":\"Enter the password associated with the SMTP server username. Click the eye icon to view the password as you type\"},{\"key\":\"secure\",\"label\":\"Use secure connection\",\"placeholder\":\"Secure\",\"type\":\"Checkbox\",\"required\":false,\"help_text\":\"Enable this if your SMTP server requires a secure connection (SSL/TLS).\"},{\"key\":\"ignoreTLS\",\"label\":\"Ignore TLS errors\",\"placeholder\":\"Ignore TLS\",\"type\":\"Checkbox\",\"required\":false,\"help_text\":\"Enable this if you want to ignore any TLS errors that may occur during the connection. Enabling this disables STARTTLS even if SMTP servers support it, hence may compromise security.\"},{\"key\":\"rejectUnauthorized\",\"label\":\"Reject unauthorized\",\"placeholder\":\"Reject unauthorized\",\"type\":\"Checkbox\",\"required\":false,\"help_text\":\"Disable this to allow connecting to an SMTP server that uses a self‑signed or otherwise invalid TLS certificate.\"}],\"actions\":[{\"label\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully installed and email notification will use SMTP configuration\",\"msgOnUninstall\":\"\",\"docs\":[]}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('spaces','Spaces','Store & deliver vast amounts of content with a simple architecture.',0,NULL,'0.0.2',NULL,'install',NULL,'plugins/spaces.png',NULL,'Storage','Storage','{\"title\":\"DigitalOcean Spaces\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"region\",\"label\":\"Region\",\"placeholder\":\"Region\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"Default set to public-read\",\"type\":\"SingleLineText\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in DigitalOcean Spaces.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('twilio','Twilio','With Twilio, unite communications and strengthen customer relationships across your business – from marketing and sales to customer service and operations.',0,NULL,'0.0.1',NULL,'install',NULL,'plugins/twilio.png',NULL,'Chat','Twilio','{\"title\":\"Configure Twilio\",\"items\":[{\"key\":\"sid\",\"label\":\"Account SID\",\"placeholder\":\"Account SID\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"token\",\"label\":\"Auth Token\",\"placeholder\":\"Auth Token\",\"type\":\"Password\",\"required\":true},{\"key\":\"from\",\"label\":\"From Phone Number\",\"placeholder\":\"From Phone Number\",\"type\":\"SingleLineText\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully installed and Twilio is enabled for notification.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('twilio-whatsapp','Whatsapp Twilio','With Twilio, unite communications and strengthen customer relationships across your business – from marketing and sales to customer service and operations.',0,NULL,'0.0.1',NULL,'install',NULL,'plugins/whatsapp.png',NULL,'Chat','Twilio','{\"title\":\"Configure Twilio\",\"items\":[{\"key\":\"sid\",\"label\":\"Account SID\",\"placeholder\":\"Account SID\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"token\",\"label\":\"Auth Token\",\"placeholder\":\"Auth Token\",\"type\":\"Password\",\"required\":true},{\"key\":\"from\",\"label\":\"From Phone Number\",\"placeholder\":\"From Phone Number\",\"type\":\"SingleLineText\",\"required\":true}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully installed and Whatsapp Twilio is enabled for notification.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('upcloud','UpCloud','The perfect home for your data. Thanks to the S3-compatible programmable interface,\nyou have a host of options for existing tools and code implementations.\n',0,NULL,'0.0.4',NULL,'install',NULL,'plugins/upcloud.png',NULL,'Storage','Storage','{\"title\":\"Configure UpCloud Object Storage\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"endpoint\",\"label\":\"Endpoint\",\"placeholder\":\"Endpoint\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"Default set to public-read\",\"type\":\"SingleLineText\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in UpCloud Object Storage.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56'),('vultr','Vultr','Using Vultr Object Storage can give flexibility and cloud storage that allows applications greater flexibility and access worldwide.',0,NULL,'0.0.4',NULL,'install',NULL,'plugins/vultr.png',NULL,'Storage','Storage','{\"title\":\"Configure Vultr Object Storage\",\"items\":[{\"key\":\"bucket\",\"label\":\"Bucket Name\",\"placeholder\":\"Bucket Name\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"hostname\",\"label\":\"Host Name\",\"placeholder\":\"e.g.: ewr1.vultrobjects.com\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_key\",\"label\":\"Access Key\",\"placeholder\":\"Access Key\",\"type\":\"SingleLineText\",\"required\":true},{\"key\":\"access_secret\",\"label\":\"Access Secret\",\"placeholder\":\"Access Secret\",\"type\":\"Password\",\"required\":true},{\"key\":\"acl\",\"label\":\"Access Control Lists (ACL)\",\"placeholder\":\"Default set to public-read\",\"type\":\"SingleLineText\",\"required\":false}],\"actions\":[{\"label\":\"Test\",\"placeholder\":\"Test\",\"key\":\"test\",\"actionType\":\"TEST\",\"type\":\"Button\"},{\"label\":\"Save\",\"placeholder\":\"Save\",\"key\":\"save\",\"actionType\":\"SUBMIT\",\"type\":\"Button\"}],\"msgOnInstall\":\"Successfully configured! Attachments will now be stored in Vultr Object Storage.\",\"msgOnUninstall\":\"\"}',NULL,NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56');
/*!40000 ALTER TABLE `nc_plugins_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_row_color_conditions`
--

DROP TABLE IF EXISTS `nc_row_color_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_row_color_conditions` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nc_order` int DEFAULT NULL,
  `is_set_as_background` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_row_color_conditions_fk_workspace_id_base_id_index` (`fk_workspace_id`,`base_id`),
  KEY `nc_row_color_conditions_fk_view_id_index` (`fk_view_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_row_color_conditions`
--

LOCK TABLES `nc_row_color_conditions` WRITE;
/*!40000 ALTER TABLE `nc_row_color_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_row_color_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_shared_bases`
--

DROP TABLE IF EXISTS `nc_shared_bases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_shared_bases` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'viewer',
  `shared_base_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_shared_bases`
--

LOCK TABLES `nc_shared_bases` WRITE;
/*!40000 ALTER TABLE `nc_shared_bases` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_shared_bases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_shared_views_v2`
--

DROP TABLE IF EXISTS `nc_shared_views_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_shared_views_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` mediumtext COLLATE utf8mb4_unicode_ci,
  `query_params` mediumtext COLLATE utf8mb4_unicode_ci,
  `view_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_all_fields` tinyint(1) DEFAULT NULL,
  `allow_copy` tinyint(1) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_shared_views_v2_fk_view_id_index` (`fk_view_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_shared_views_v2`
--

LOCK TABLES `nc_shared_views_v2` WRITE;
/*!40000 ALTER TABLE `nc_shared_views_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_shared_views_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_sort_v2`
--

DROP TABLE IF EXISTS `nc_sort_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_sort_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_column_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'false',
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_sort_v2_fk_view_id_index` (`fk_view_id`),
  KEY `nc_sort_v2_fk_column_id_index` (`fk_column_id`),
  KEY `nc_sort_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_sort_v2`
--

LOCK TABLES `nc_sort_v2` WRITE;
/*!40000 ALTER TABLE `nc_sort_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_sort_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_sources_v2`
--

DROP TABLE IF EXISTS `nc_sources_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_sources_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `is_meta` tinyint(1) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inflection_column` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inflection_table` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enabled` tinyint(1) DEFAULT '1',
  `order` float(8,2) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `erd_uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `is_schema_readonly` tinyint(1) DEFAULT '0',
  `is_data_readonly` tinyint(1) DEFAULT '0',
  `fk_integration_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_local` tinyint(1) DEFAULT '0',
  `is_encrypted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `nc_sources_v2_base_id_index` (`base_id`),
  KEY `nc_sources_v2_fk_integration_id_index` (`fk_integration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_sources_v2`
--

LOCK TABLES `nc_sources_v2` WRITE;
/*!40000 ALTER TABLE `nc_sources_v2` DISABLE KEYS */;
INSERT INTO `nc_sources_v2` VALUES ('bqmzx5degwt3dui','pixp4cik3n9fbbq',NULL,NULL,NULL,1,'mysql2','camelize','camelize','2025-11-08 23:34:23','2025-11-08 23:34:23',1,1.00,NULL,NULL,0,0,0,NULL,0,0);
/*!40000 ALTER TABLE `nc_sources_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_store`
--

DROP TABLE IF EXISTS `nc_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_store` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `base_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'db',
  `key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `env` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_store_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_store`
--

LOCK TABLES `nc_store` WRITE;
/*!40000 ALTER TABLE `nc_store` DISABLE KEYS */;
INSERT INTO `nc_store` VALUES (1,NULL,'','NC_DEBUG','{\"nc:app\":false,\"nc:api:rest\":false,\"nc:api:source\":false,\"nc:api:gql\":false,\"nc:api:grpc\":false,\"nc:migrator\":false,\"nc:datamapper\":false}',NULL,NULL,NULL,NULL,NULL),(2,NULL,'','NC_PROJECT_COUNT','0',NULL,NULL,NULL,NULL,NULL),(3,NULL,'db','NC_MIGRATION_JOBS','{\"version\":\"9\",\"stall_check\":1762643617834,\"locked\":false}',NULL,NULL,NULL,'2025-11-08 23:13:55','2025-11-08 23:13:55'),(4,NULL,'db','nc_server_id','2c2ca9c8a052283efc000c0590762af718d369b99328abaa4e0b2f0ea5462e1a',NULL,NULL,NULL,'2025-11-08 23:13:55','2025-11-08 23:13:55'),(5,NULL,'db','NC_CONFIG_MAIN','{\"version\":\"0258003\"}',NULL,NULL,NULL,'2025-11-08 23:13:56','2025-11-08 23:13:56');
/*!40000 ALTER TABLE `nc_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_sync_configs`
--

DROP TABLE IF EXISTS `nc_sync_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_sync_configs` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_integration_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sync_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sync_trigger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sync_trigger_cron` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sync_trigger_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sync_job_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_sync_at` datetime DEFAULT NULL,
  `next_sync_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sync_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_parent_sync_config_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `on_delete_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'mark_deleted',
  PRIMARY KEY (`id`),
  KEY `sync_configs_integration_model` (`fk_model_id`,`fk_integration_id`),
  KEY `nc_sync_configs_context` (`base_id`,`fk_workspace_id`),
  KEY `nc_sync_configs_parent_idx` (`fk_parent_sync_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_sync_configs`
--

LOCK TABLES `nc_sync_configs` WRITE;
/*!40000 ALTER TABLE `nc_sync_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_sync_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_sync_logs_v2`
--

DROP TABLE IF EXISTS `nc_sync_logs_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_sync_logs_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_sync_source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_taken` int DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_sync_logs_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_sync_logs_v2`
--

LOCK TABLES `nc_sync_logs_v2` WRITE;
/*!40000 ALTER TABLE `nc_sync_logs_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_sync_logs_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_sync_mappings`
--

DROP TABLE IF EXISTS `nc_sync_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_sync_mappings` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_sync_config_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_table` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_sync_mappings_context` (`base_id`,`fk_workspace_id`),
  KEY `nc_sync_mappings_sync_config_idx` (`fk_sync_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_sync_mappings`
--

LOCK TABLES `nc_sync_mappings` WRITE;
/*!40000 ALTER TABLE `nc_sync_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_sync_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_sync_source_v2`
--

DROP TABLE IF EXISTS `nc_sync_source_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_sync_source_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `deleted` tinyint(1) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `order` float(8,2) DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_sync_source_v2_fk_user_id_foreign` (`fk_user_id`),
  KEY `nc_sync_source_v2_source_id_index` (`source_id`),
  KEY `nc_sync_source_v2_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_sync_source_v2`
--

LOCK TABLES `nc_sync_source_v2` WRITE;
/*!40000 ALTER TABLE `nc_sync_source_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_sync_source_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_team_users_v2`
--

DROP TABLE IF EXISTS `nc_team_users_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_team_users_v2` (
  `org_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `nc_team_users_v2_org_id_foreign` (`org_id`),
  KEY `nc_team_users_v2_user_id_foreign` (`user_id`),
  CONSTRAINT `nc_team_users_v2_org_id_foreign` FOREIGN KEY (`org_id`) REFERENCES `nc_orgs_v2` (`id`),
  CONSTRAINT `nc_team_users_v2_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `nc_users_v2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_team_users_v2`
--

LOCK TABLES `nc_team_users_v2` WRITE;
/*!40000 ALTER TABLE `nc_team_users_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_team_users_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_teams_v2`
--

DROP TABLE IF EXISTS `nc_teams_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_teams_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `org_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nc_teams_v2_org_id_foreign` (`org_id`),
  CONSTRAINT `nc_teams_v2_org_id_foreign` FOREIGN KEY (`org_id`) REFERENCES `nc_orgs_v2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_teams_v2`
--

LOCK TABLES `nc_teams_v2` WRITE;
/*!40000 ALTER TABLE `nc_teams_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_teams_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_user_comment_notifications_preference`
--

DROP TABLE IF EXISTS `nc_user_comment_notifications_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_user_comment_notifications_preference` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferences` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_comments_preference_index` (`user_id`,`row_id`,`fk_model_id`),
  KEY `nc_user_comment_notifications_preference_base_id_index` (`base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_user_comment_notifications_preference`
--

LOCK TABLES `nc_user_comment_notifications_preference` WRITE;
/*!40000 ALTER TABLE `nc_user_comment_notifications_preference` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_user_comment_notifications_preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_user_refresh_tokens`
--

DROP TABLE IF EXISTS `nc_user_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_user_refresh_tokens` (
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `nc_user_refresh_tokens_fk_user_id_index` (`fk_user_id`),
  KEY `nc_user_refresh_tokens_token_index` (`token`),
  KEY `nc_user_refresh_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_user_refresh_tokens`
--

LOCK TABLES `nc_user_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `nc_user_refresh_tokens` DISABLE KEYS */;
INSERT INTO `nc_user_refresh_tokens` VALUES ('usfwuzdmgrr348dy','dc0a075f14d7db99b36ae0676251370597c4de255e5322ec076117e675beddbe7c3f36959832a834',NULL,'2025-12-08 22:02:00','2025-11-09 03:01:59','2025-11-09 03:01:59'),('usfwuzdmgrr348dy','1cb82fd84cb2cc9191496fb06e221e22d9d094b9f5d8b0a25b40eef8206cd1d00d8da8648e180358',NULL,'2025-12-09 08:02:34','2025-11-09 03:02:06','2025-11-09 13:02:33'),('usc8u5scvvx5ftm7','39312a19d2dc4a5ec4aa70cd8e7d68dbbdfe667de108d4f0a4b8e4291aba453d5e5779def2fd8067',NULL,'2025-12-08 22:03:03','2025-11-09 03:03:03','2025-11-09 03:03:03');
/*!40000 ALTER TABLE `nc_user_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_users_v2`
--

DROP TABLE IF EXISTS `nc_users_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_users_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invite_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invite_token_expires` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_expires` timestamp NULL DEFAULT NULL,
  `reset_password_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verification_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT NULL,
  `roles` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'editor',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token_version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blocked` tinyint(1) DEFAULT '0',
  `blocked_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  `meta` text COLLATE utf8mb4_unicode_ci,
  `is_new_user` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_users_v2_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_users_v2`
--

LOCK TABLES `nc_users_v2` WRITE;
/*!40000 ALTER TABLE `nc_users_v2` DISABLE KEYS */;
INSERT INTO `nc_users_v2` VALUES ('usc8u5scvvx5ftm7','alirubass.cs@gmail.com','$2a$10$PeOnPrPyk1s8a.NPE0O5J.BblJMc1jX6cAsxCTtYGGnxaY.T3NcYy','$2a$10$PeOnPrPyk1s8a.NPE0O5J.',NULL,NULL,NULL,NULL,'516262c3-d543-4a76-8ba1-546972e43909',NULL,'org-level-viewer','2025-11-09 03:03:03','2025-11-09 03:03:09','b2197b22d9f8f5b4cb2f55cae719c80c79fb98823af709e348fdd8b35da40f30ad4bff43e528a221',NULL,NULL,0,NULL,NULL,0,NULL,0),('usfwuzdmgrr348dy','admin@gmail.com','$2a$10$OIpSt6n4DXYgUkrs8B6qSuceKc92OFBw3jsmOlZ512nL58FTDmo3e','$2a$10$OIpSt6n4DXYgUkrs8B6qSu',NULL,NULL,NULL,NULL,'049cd963-5acd-40dc-b4f9-cc96bebf0088',NULL,'org-level-creator,super','2025-11-08 23:19:36','2025-11-09 03:01:59','a2ea27903bf3d1e11d67b3a19e42f746a3913daa7fc5795ffd752268e50f57461554a9424616b558',NULL,NULL,0,NULL,NULL,0,NULL,0),('usknr6o0pvhe03gd','admin@wcrbusiness.online','$2a$10$ldquwQdvGLB2/mW4wyUFNe60XInSVfQPsbVNj3AAaeHwQIbw5V0Yy','$2a$10$ldquwQdvGLB2/mW4wyUFNe',NULL,NULL,NULL,NULL,'d122c582-1275-4ced-91fd-333d01f5ef48',NULL,'org-level-creator,super','2025-11-08 23:13:56','2025-11-08 23:13:56','46793cc5af7a597324ab4b5dd15590a1d24c0e8f9727c9dc6351cbd7753805981181c7469bae1c9c',NULL,NULL,0,NULL,NULL,0,NULL,1);
/*!40000 ALTER TABLE `nc_users_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_views_v2`
--

DROP TABLE IF EXISTS `nc_views_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_views_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `show_system_fields` tinyint(1) DEFAULT NULL,
  `lock_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'collaborative',
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show` tinyint(1) DEFAULT NULL,
  `order` float(8,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owned_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row_coloring_mode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_views_v2_fk_model_id_index` (`fk_model_id`),
  KEY `nc_views_v2_base_id_index` (`base_id`),
  KEY `nc_views_v2_created_by_index` (`created_by`),
  KEY `nc_views_v2_owned_by_index` (`owned_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_views_v2`
--

LOCK TABLES `nc_views_v2` WRITE;
/*!40000 ALTER TABLE `nc_views_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_views_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nc_widgets_v2`
--

DROP TABLE IF EXISTS `nc_widgets_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nc_widgets_v2` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_workspace_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_dashboard_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_model_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_view_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `order` int unsigned DEFAULT NULL,
  `position` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `error` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nc_widgets_context` (`base_id`,`fk_workspace_id`),
  KEY `nc_widgets_dashboard_idx` (`fk_dashboard_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nc_widgets_v2`
--

LOCK TABLES `nc_widgets_v2` WRITE;
/*!40000 ALTER TABLE `nc_widgets_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `nc_widgets_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `is_read` tinyint(1) DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0',
  `fk_user_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `notification_fk_user_id_index` (`fk_user_id`),
  KEY `notification_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES ('nc9m8ohn5xuyuzbp','app.welcome','{}',0,0,'usfwuzdmgrr348dy','2025-11-08 23:19:36','2025-11-08 23:19:36'),('ncap53829v01k8at','base.invite','{\"base\":{\"id\":\"pixp4cik3n9fbbq\",\"title\":\"Base\"},\"user\":{\"id\":\"usfwuzdmgrr348dy\",\"email\":\"admin@gmail.com\",\"displayName\":null,\"meta\":null}}',0,0,'usc8u5scvvx5ftm7','2025-11-09 03:03:42','2025-11-09 03:03:42'),('nctq1xubu0a0o3yh','app.welcome','{}',0,0,'usc8u5scvvx5ftm7','2025-11-09 03:03:03','2025-11-09 03:03:03');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xc_knex_migrations`
--

DROP TABLE IF EXISTS `xc_knex_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xc_knex_migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch` int DEFAULT NULL,
  `migration_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xc_knex_migrations`
--

LOCK TABLES `xc_knex_migrations` WRITE;
/*!40000 ALTER TABLE `xc_knex_migrations` DISABLE KEYS */;
INSERT INTO `xc_knex_migrations` VALUES (1,'project',1,'2025-11-08 18:13:40'),(2,'m2m',1,'2025-11-08 18:13:40'),(3,'fkn',1,'2025-11-08 18:13:40'),(4,'viewType',1,'2025-11-08 18:13:40'),(5,'viewName',1,'2025-11-08 18:13:40'),(6,'nc_006_alter_nc_shared_views',1,'2025-11-08 18:13:40'),(7,'nc_007_alter_nc_shared_views_1',1,'2025-11-08 18:13:40'),(8,'nc_008_add_nc_shared_bases',1,'2025-11-08 18:13:40'),(9,'nc_009_add_model_order',1,'2025-11-08 18:13:40'),(10,'nc_010_add_parent_title_column',1,'2025-11-08 18:13:40'),(11,'nc_011_remove_old_ses_plugin',1,'2025-11-08 18:13:40'),(12,'nc_012_cloud_cleanup',1,'2025-11-08 18:13:40');
/*!40000 ALTER TABLE `xc_knex_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xc_knex_migrations_lock`
--

DROP TABLE IF EXISTS `xc_knex_migrations_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xc_knex_migrations_lock` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `is_locked` int DEFAULT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xc_knex_migrations_lock`
--

LOCK TABLES `xc_knex_migrations_lock` WRITE;
/*!40000 ALTER TABLE `xc_knex_migrations_lock` DISABLE KEYS */;
INSERT INTO `xc_knex_migrations_lock` VALUES (1,0);
/*!40000 ALTER TABLE `xc_knex_migrations_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xc_knex_migrationsv2`
--

DROP TABLE IF EXISTS `xc_knex_migrationsv2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xc_knex_migrationsv2` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch` int DEFAULT NULL,
  `migration_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xc_knex_migrationsv2`
--

LOCK TABLES `xc_knex_migrationsv2` WRITE;
/*!40000 ALTER TABLE `xc_knex_migrationsv2` DISABLE KEYS */;
INSERT INTO `xc_knex_migrationsv2` VALUES (1,'nc_011',1,'2025-11-08 18:13:44'),(2,'nc_012_alter_column_data_types',1,'2025-11-08 18:13:44'),(3,'nc_013_sync_source',1,'2025-11-08 18:13:44'),(4,'nc_014_alter_column_data_types',1,'2025-11-08 18:13:44'),(5,'nc_015_add_meta_col_in_column_table',1,'2025-11-08 18:13:44'),(6,'nc_016_alter_hooklog_payload_types',1,'2025-11-08 18:13:44'),(7,'nc_017_add_user_token_version_column',1,'2025-11-08 18:13:45'),(8,'nc_018_add_meta_in_view',1,'2025-11-08 18:13:45'),(9,'nc_019_add_meta_in_meta_tables',1,'2025-11-08 18:13:45'),(10,'nc_020_kanban_view',1,'2025-11-08 18:13:45'),(11,'nc_021_add_fields_in_token',1,'2025-11-08 18:13:45'),(12,'nc_022_qr_code_column_type',1,'2025-11-08 18:13:45'),(13,'nc_023_multiple_source',1,'2025-11-08 18:13:45'),(14,'nc_024_barcode_column_type',1,'2025-11-08 18:13:45'),(15,'nc_025_add_row_height',1,'2025-11-08 18:13:45'),(16,'nc_026_map_view',1,'2025-11-08 18:13:46'),(17,'nc_027_add_comparison_sub_op',1,'2025-11-08 18:13:46'),(18,'nc_028_add_enable_scanner_in_form_columns_meta_table',1,'2025-11-08 18:13:46'),(19,'nc_029_webhook',1,'2025-11-08 18:13:46'),(20,'nc_030_add_description_field',1,'2025-11-08 18:13:46'),(21,'nc_031_remove_fk_and_add_idx',1,'2025-11-08 18:13:49'),(22,'nc_033_add_group_by',1,'2025-11-08 18:13:49'),(23,'nc_034_erd_filter_and_notification',1,'2025-11-08 18:13:49'),(24,'nc_035_add_username_to_users',1,'2025-11-08 18:13:49'),(25,'nc_036_base_deleted',1,'2025-11-08 18:13:49'),(26,'nc_037_rename_project_and_base',1,'2025-11-08 18:13:50'),(27,'nc_038_formula_parsed_tree_column',1,'2025-11-08 18:13:50'),(28,'nc_039_sqlite_alter_column_types',1,'2025-11-08 18:13:50'),(29,'nc_040_form_view_alter_column_types',1,'2025-11-08 18:13:50'),(30,'nc_041_calendar_view',1,'2025-11-08 18:13:50'),(31,'nc_042_user_block',1,'2025-11-08 18:13:50'),(32,'nc_043_user_refresh_token',1,'2025-11-08 18:13:50'),(33,'nc_044_view_column_index',1,'2025-11-08 18:13:51'),(34,'nc_045_extensions',1,'2025-11-08 18:13:51'),(35,'nc_046_comment_mentions',1,'2025-11-08 18:13:51'),(36,'nc_047_comment_migration',1,'2025-11-08 18:13:51'),(37,'nc_048_view_links',1,'2025-11-08 18:13:51'),(38,'nc_049_clear_notifications',1,'2025-11-08 18:13:51'),(39,'nc_050_tenant_isolation',1,'2025-11-08 18:13:52'),(40,'nc_051_source_readonly_columns',1,'2025-11-08 18:13:52'),(41,'nc_052_field_aggregation',1,'2025-11-08 18:13:52'),(42,'nc_053_jobs',1,'2025-11-08 18:13:52'),(43,'nc_054_id_length',1,'2025-11-08 18:13:53'),(44,'nc_055_junction_pk',1,'2025-11-08 18:13:53'),(45,'nc_056_integration',1,'2025-11-08 18:13:54'),(46,'nc_057_file_references',1,'2025-11-08 18:13:54'),(47,'nc_058_button_colum',1,'2025-11-08 18:13:54'),(48,'nc_059_invited_by',1,'2025-11-08 18:13:54'),(49,'nc_060_descriptions',1,'2025-11-08 18:13:54'),(50,'nc_061_integration_is_default',1,'2025-11-08 18:13:54'),(51,'nc_062_integration_store',1,'2025-11-08 18:13:54'),(52,'nc_063_form_field_filter',1,'2025-11-08 18:13:54'),(53,'nc_064_pg_minimal_dbs',1,'2025-11-08 18:13:54'),(54,'nc_065_encrypt_flag',1,'2025-11-08 18:13:54'),(55,'nc_066_ai_button',1,'2025-11-08 18:13:54'),(56,'nc_067_personal_view',1,'2025-11-08 18:13:54'),(57,'nc_068_user_delete',1,'2025-11-08 18:13:54'),(58,'nc_069_ai_prompt',1,'2025-11-08 18:13:54'),(59,'nc_070_data_reflection',1,'2025-11-08 18:13:54'),(60,'nc_071_add_meta_in_users',1,'2025-11-08 18:13:54'),(61,'nc_072_col_button_pk',1,'2025-11-08 18:13:54'),(62,'nc_073_file_reference_indexes',1,'2025-11-08 18:13:54'),(63,'nc_074_missing_context_indexes',1,'2025-11-08 18:13:55'),(64,'nc_075_audit_refactor',1,'2025-11-08 18:13:55'),(65,'nc_076_sync_configs',1,'2025-11-08 18:13:55'),(66,'nc_077_column_index_name',1,'2025-11-08 18:13:55'),(67,'nc_078_mcp_tokens',1,'2025-11-08 18:13:55'),(68,'nc_079_cross_base_link',1,'2025-11-08 18:13:55'),(69,'nc_080_sync_mappings',1,'2025-11-08 18:13:55'),(70,'nc_081_audit',1,'2025-11-08 18:13:55'),(71,'nc_082_row_color_conditions',1,'2025-11-08 18:13:55'),(72,'nc_083_permissions',1,'2025-11-08 18:13:55'),(73,'nc_084_hook_trigger_fields',1,'2025-11-08 18:13:55'),(74,'nc_085_base_default_role',1,'2025-11-08 18:13:56'),(75,'nc_086_dashboards_widgets',1,'2025-11-08 18:13:56'),(76,'nc_087_widget_error',1,'2025-11-08 18:13:56'),(77,'nc_088_add_sso_client_to_api_tokens',1,'2025-11-08 18:13:56'),(78,'nc_089_dashboard_sharing',1,'2025-11-08 18:13:56'),(79,'nc_090_add_is_new_user_to_users',1,'2025-11-08 18:13:56'),(80,'nc_091_unify_model',1,'2025-11-08 18:13:56');
/*!40000 ALTER TABLE `xc_knex_migrationsv2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xc_knex_migrationsv2_lock`
--

DROP TABLE IF EXISTS `xc_knex_migrationsv2_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xc_knex_migrationsv2_lock` (
  `index` int unsigned NOT NULL AUTO_INCREMENT,
  `is_locked` int DEFAULT NULL,
  PRIMARY KEY (`index`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xc_knex_migrationsv2_lock`
--

LOCK TABLES `xc_knex_migrationsv2_lock` WRITE;
/*!40000 ALTER TABLE `xc_knex_migrationsv2_lock` DISABLE KEYS */;
INSERT INTO `xc_knex_migrationsv2_lock` VALUES (1,0);
/*!40000 ALTER TABLE `xc_knex_migrationsv2_lock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-10  2:00:03
