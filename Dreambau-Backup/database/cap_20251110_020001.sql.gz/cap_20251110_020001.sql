-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: cap
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__drizzle_migrations`
--

DROP TABLE IF EXISTS `__drizzle_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `__drizzle_migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hash` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__drizzle_migrations`
--

LOCK TABLES `__drizzle_migrations` WRITE;
/*!40000 ALTER TABLE `__drizzle_migrations` DISABLE KEYS */;
INSERT INTO `__drizzle_migrations` VALUES (1,'87fa199df5a1d95b5b471c56327989dd46c2c5f1c2ae816eaac7c71026a53ba9',1743020179593),(2,'f17c805c801fea22b6f34d67344b877085cf6c8f79435591ba6195708b2cdaac',1749268354138),(3,'60f024fb2aa4bce3288667ef77742e0d80942e28925abf001080e228947a2ea4',1750935538683),(4,'066bad93302f935f711457bf1f4c49420087712828aa6637d4ee8cd7550220e1',1761710697286),(5,'2a0659c19cebf0fde120d4e5e48cc68da680d66216c85106334ec6e19b557424',1761711378574),(6,'7d3857766a3dfd528bff2919bf097fc151fc0bca5a20e1938070759d7ed50eec',1761711605408),(7,'e4e29562ec7dcfdef672d18c36836c176b99d08b3cba975b990f13358af3482e',1762410865419);
/*!40000 ALTER TABLE `__drizzle_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerAccountId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `expires_in` int DEFAULT NULL,
  `id_token` text COLLATE utf8mb4_unicode_ci,
  `refresh_token` text COLLATE utf8mb4_unicode_ci,
  `refresh_token_expires_in` int DEFAULT NULL,
  `scope` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `tempColumn` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_id_unique` (`id`),
  KEY `user_id_idx` (`userId`),
  KEY `provider_account_id_idx` (`providerAccountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_api_keys`
--

DROP TABLE IF EXISTS `auth_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_api_keys` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_api_keys_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_api_keys`
--

LOCK TABLES `auth_api_keys` WRITE;
/*!40000 ALTER TABLE `auth_api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` float DEFAULT NULL,
  `authorId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `videoId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `parentCommentId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comments_id_unique` (`id`),
  KEY `video_id_idx` (`videoId`),
  KEY `author_id_idx` (`authorId`),
  KEY `parent_comment_id_idx` (`parentCommentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `organizationId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdById` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parentId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spaceId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folders_id_unique` (`id`),
  KEY `organization_id_idx` (`organizationId`),
  KEY `created_by_id_idx` (`createdById`),
  KEY `parent_id_idx` (`parentId`),
  KEY `space_id_idx` (`spaceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders`
--

LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imported_videos`
--

DROP TABLE IF EXISTS `imported_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imported_videos` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orgId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`orgId`,`source`,`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imported_videos`
--

LOCK TABLES `imported_videos` WRITE;
/*!40000 ALTER TABLE `imported_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `imported_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orgId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipientId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` json NOT NULL,
  `readAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `notifications_id_unique` (`id`),
  KEY `recipient_id_idx` (`recipientId`),
  KEY `org_id_idx` (`orgId`),
  KEY `type_idx` (`type`),
  KEY `read_at_idx` (`readAt`),
  KEY `created_at_idx` (`createdAt`),
  KEY `recipient_read_idx` (`recipientId`,`readAt`),
  KEY `recipient_created_idx` (`recipientId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_invites`
--

DROP TABLE IF EXISTS `organization_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_invites` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizationId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invitedEmail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invitedByUserId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `expiresAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organization_invites_id_unique` (`id`),
  KEY `invited_email_idx` (`invitedEmail`),
  KEY `invited_by_user_id_idx` (`invitedByUserId`),
  KEY `status_idx` (`status`),
  KEY `organization_id_idx` (`organizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_invites`
--

LOCK TABLES `organization_invites` WRITE;
/*!40000 ALTER TABLE `organization_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_members`
--

DROP TABLE IF EXISTS `organization_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_members` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizationId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organization_members_id_unique` (`id`),
  KEY `user_id_idx` (`userId`),
  KEY `organization_id_idx` (`organizationId`),
  KEY `user_id_organization_id_idx` (`userId`,`organizationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_members`
--

LOCK TABLES `organization_members` WRITE;
/*!40000 ALTER TABLE `organization_members` DISABLE KEYS */;
INSERT INTO `organization_members` VALUES ('mxqbqrzjjdezjda','kx0bs7zdfw4vpe2','c4vvh9hxh9tdkbj','owner','2025-11-09 01:32:57','2025-11-09 01:32:57'),('q6hpr245ebbbba7','t5ekmw4jn99fyca','0f2vtges6t34ys9','owner','2025-11-09 01:44:19','2025-11-09 01:44:19');
/*!40000 ALTER TABLE `organization_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownerId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `allowedEmailDomain` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customDomain` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domainVerified` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `workosOrganizationId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workosConnectionId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iconUrl` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `tombstoneAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organizations_id_unique` (`id`),
  KEY `owner_id_idx` (`ownerId`),
  KEY `custom_domain_idx` (`customDomain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES ('0f2vtges6t34ys9','WCR\'s organization','t5ekmw4jn99fyca',NULL,NULL,NULL,NULL,'2025-11-09 01:44:19','2025-11-09 01:44:29',NULL,NULL,NULL,NULL,NULL),('c4vvh9hxh9tdkbj','WCR','kx0bs7zdfw4vpe2',NULL,NULL,NULL,NULL,'2025-11-09 01:32:57','2025-11-09 01:41:46',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s3_buckets`
--

DROP TABLE IF EXISTS `s3_buckets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `s3_buckets` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownerId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint` text COLLATE utf8mb4_unicode_ci,
  `bucketName` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessKeyId` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secretAccessKey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` text COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (_utf8mb4'aws'),
  PRIMARY KEY (`id`),
  UNIQUE KEY `s3_buckets_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s3_buckets`
--

LOCK TABLES `s3_buckets` WRITE;
/*!40000 ALTER TABLE `s3_buckets` DISABLE KEYS */;
/*!40000 ALTER TABLE `s3_buckets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sessionToken` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_id_unique` (`id`),
  UNIQUE KEY `sessions_sessionToken_unique` (`sessionToken`),
  UNIQUE KEY `session_token_idx` (`sessionToken`),
  KEY `user_id_idx` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shared_videos`
--

DROP TABLE IF EXISTS `shared_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shared_videos` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `videoId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizationId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sharedByUserId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sharedAt` timestamp NOT NULL DEFAULT (now()),
  `folderId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shared_videos_id_unique` (`id`),
  KEY `video_id_idx` (`videoId`),
  KEY `shared_by_user_id_idx` (`sharedByUserId`),
  KEY `organization_id_idx` (`organizationId`),
  KEY `video_id_organization_id_idx` (`videoId`,`organizationId`),
  KEY `folder_id_idx` (`folderId`),
  KEY `video_id_folder_id_idx` (`videoId`,`folderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shared_videos`
--

LOCK TABLES `shared_videos` WRITE;
/*!40000 ALTER TABLE `shared_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `shared_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `space_members`
--

DROP TABLE IF EXISTS `space_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `space_members` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spaceId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `space_members_id_unique` (`id`),
  UNIQUE KEY `space_id_user_id_unique` (`spaceId`,`userId`),
  KEY `space_id_idx` (`spaceId`),
  KEY `user_id_idx` (`userId`),
  KEY `space_id_user_id_idx` (`spaceId`,`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `space_members`
--

LOCK TABLES `space_members` WRITE;
/*!40000 ALTER TABLE `space_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `space_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `space_videos`
--

DROP TABLE IF EXISTS `space_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `space_videos` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spaceId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `videoId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addedById` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addedAt` timestamp NOT NULL DEFAULT (now()),
  `folderId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `space_videos_id_unique` (`id`),
  KEY `space_id_idx` (`spaceId`),
  KEY `video_id_idx` (`videoId`),
  KEY `added_by_id_idx` (`addedById`),
  KEY `space_id_video_id_idx` (`spaceId`,`videoId`),
  KEY `folder_id_idx` (`folderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `space_videos`
--

LOCK TABLES `space_videos` WRITE;
/*!40000 ALTER TABLE `space_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `space_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spaces`
--

DROP TABLE IF EXISTS `spaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spaces` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `primary` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizationId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdById` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iconUrl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `privacy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Private',
  PRIMARY KEY (`id`),
  UNIQUE KEY `spaces_id_unique` (`id`),
  KEY `organization_id_idx` (`organizationId`),
  KEY `created_by_id_idx` (`createdById`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spaces`
--

LOCK TABLES `spaces` WRITE;
/*!40000 ALTER TABLE `spaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `spaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emailVerified` timestamp NULL DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripeCustomerId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripeSubscriptionId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thirdPartyStripeSubscriptionId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripeSubscriptionStatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripeSubscriptionPriceId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activeOrganizationId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `onboarding_completed_at` timestamp NULL DEFAULT NULL,
  `customBucket` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inviteQuota` int NOT NULL DEFAULT '1',
  `preferences` json DEFAULT (_utf8mb4'null'),
  `onboardingSteps` json DEFAULT NULL,
  `defaultOrgId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_id_unique` (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `email_idx` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('kx0bs7zdfw4vpe2','Ali','Rubass','alirubass.cs@gmail.com','2025-11-09 01:32:58',NULL,NULL,NULL,NULL,NULL,NULL,'c4vvh9hxh9tdkbj','2025-11-09 01:32:57','2025-11-09 01:33:19',NULL,NULL,1,'null','{\"welcome\": true, \"download\": true, \"inviteTeam\": true, \"customDomain\": true, \"organizationSetup\": true}','c4vvh9hxh9tdkbj'),('t5ekmw4jn99fyca','WCR','','admin@gmail.com','2025-11-09 01:44:20',NULL,NULL,NULL,NULL,NULL,NULL,'0f2vtges6t34ys9','2025-11-09 01:44:19','2025-11-09 01:44:42',NULL,NULL,1,'null','{\"welcome\": true, \"download\": true, \"inviteTeam\": true, \"customDomain\": true, \"organizationSetup\": true}','0f2vtges6t34ys9');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_tokens`
--

DROP TABLE IF EXISTS `verification_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_tokens` (
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`identifier`),
  UNIQUE KEY `verification_tokens_token_unique` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_tokens`
--

LOCK TABLES `verification_tokens` WRITE;
/*!40000 ALTER TABLE `verification_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_uploads`
--

DROP TABLE IF EXISTS `video_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_uploads` (
  `video_id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaded` int NOT NULL DEFAULT '0',
  `total` int NOT NULL DEFAULT '0',
  `started_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()),
  `mode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_uploads`
--

LOCK TABLES `video_uploads` WRITE;
/*!40000 ALTER TABLE `video_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos` (
  `id` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownerId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'My Video',
  `awsRegion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `awsBucket` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bucket` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '1',
  `videoStartTime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audioStartTime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xStreamInfo` text COLLATE utf8mb4_unicode_ci,
  `jobId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jobStatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isScreenshot` tinyint(1) NOT NULL DEFAULT '0',
  `skipProcessing` tinyint(1) NOT NULL DEFAULT '0',
  `transcriptionStatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `source` json NOT NULL DEFAULT (_utf8mb4'{"type":"MediaConvert"}'),
  `password` text COLLATE utf8mb4_unicode_ci,
  `duration` float DEFAULT NULL,
  `width` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `fps` int DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `folderId` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orgId` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `videos_id_unique` (`id`),
  KEY `id_idx` (`id`),
  KEY `owner_id_idx` (`ownerId`),
  KEY `is_public_idx` (`public`),
  KEY `folder_id_idx` (`folderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-10  2:00:05
